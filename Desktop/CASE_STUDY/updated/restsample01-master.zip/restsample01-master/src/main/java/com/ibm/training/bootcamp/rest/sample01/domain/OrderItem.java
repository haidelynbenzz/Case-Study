package com.ibm.training.bootcamp.rest.sample01.domain;

public class OrderItem {

	Long id;
	private String Quantity;
	private String TotalPrice;

	
	public OrderItem() {
		
	}
	
	public OrderItem(String Quantity, String TotalPrice) {
		this(null, Quantity, TotalPrice);
	}
	
	public OrderItem(Long id, String Quantity, String TotalPrice) {
		this.id = id;
		this.Quantity = Quantity;
		this.TotalPrice = TotalPrice;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getQuantity() {
		return Quantity;
	}

	public void setQuantity(String quantity) {
		Quantity = quantity;
	}

	public String getTotalPrice() {
		return TotalPrice;
	}

	public void setTotalPrice(String totalPrice) {
		TotalPrice = totalPrice;
	}

	
	
}
