package com.ibm.training.bootcamp.rest.sample01.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.ibm.training.bootcamp.rest.sample01.dao.FoodJdbcDaoImpl;
import com.ibm.training.bootcamp.rest.sample01.dao.OrderItemsDao;
import com.ibm.training.bootcamp.rest.sample01.domain.OrderItem;

public class OrderItemServiceImpl implements OrderItemService{
	
	OrderItemsDao orderItemDao;

	public OrderItemServiceImpl() {
		this.orderItemDao = FoodJdbcDaoImpl.getInstance();
		//this.foodDao = UserHashMapDaoImpl.getInstance();
	}
	

	@Override
	public List<OrderItem> findAllOrderItem(){
		return orderItemDao.findAllOrderItem();
	}
	
	public OrderItem findOrderItem(Long id) {
		return orderItemDao.findOrderItem(id);
	}
	
	public List<OrderItem> findByOrderItem(String Quantity, String TotalPrice){
		return orderItemDao.findByOrderItem(Quantity, TotalPrice);
	}
	
	@Override
	public void addOrderItem(OrderItem orderItem) {
		if (validate(orderItem)) {
			orderItemDao.addOrderItem(orderItem);
		} else {
			throw new IllegalArgumentException("Fields Quantity, TotalPrice.");
		}
	}
	
	@Override
	public void upsertOrderItem(OrderItem orderItem) {
		if (validate(orderItem)) {
			if(orderItem.getId() != null && orderItem.getId() >= 0) {
				System.out.println("Order Item Updated");
				orderItemDao.updateOrderItem(orderItem);
			} else {
				System.out.println("Order Item Added");
				orderItemDao.addOrderItem(orderItem);
			}
		} else {
			throw new IllegalArgumentException("Fields FoodItemName, UnitPrice and InStock cannot be blank.");
		}
	}
	
	@Override
	public void deleteOrderItem(Long id) {
		orderItemDao.deleteOrderItem(id);
	}
	
	private boolean validate(OrderItem orderItem) {
		return !StringUtils.isAnyBlank(orderItem.getQuantity(), orderItem.getTotalPrice());
	}


}
