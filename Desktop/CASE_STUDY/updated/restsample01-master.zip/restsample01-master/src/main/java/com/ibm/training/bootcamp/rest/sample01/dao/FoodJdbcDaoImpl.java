package com.ibm.training.bootcamp.rest.sample01.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hsqldb.jdbc.JDBCDataSource;

import com.ibm.training.bootcamp.rest.sample01.domain.Food;
import com.ibm.training.bootcamp.rest.sample01.domain.Order;
import com.ibm.training.bootcamp.rest.sample01.domain.OrderItem;

public class FoodJdbcDaoImpl implements FoodDao, OrderDao, OrderItemsDao {

	
private static FoodJdbcDaoImpl INSTANCE;
	
	private JDBCDataSource dataSource;
	
	static public FoodJdbcDaoImpl getInstance() {
		
		FoodJdbcDaoImpl instance;
		if(INSTANCE != null) {
			instance = INSTANCE;
		}else {
			instance = new FoodJdbcDaoImpl();
			INSTANCE = instance;
		}
		
		return instance;
	}
	
	private FoodJdbcDaoImpl() {
		init();
	}
	
	private void init() {
		dataSource = new JDBCDataSource();
		dataSource.setDatabase("jdbc:hsqldb:mem:USER");
		dataSource.setUser("username");
		dataSource.setPassword("password");
		
		
		createFoodItemTbl();
		insertInitFoodItem();
		
		createOrderTbl();
		insertInitOrder();
		
		createOrderItemsTbl();
		insertInitOrderItem();
		
	}
	
	private void createFoodItemTbl() {
		String createSqlFoodItemTbl = "CREATE TABLE FoodItemTbl " 
				+ "(id INTEGER IDENTITY PRIMARY KEY, " 
				+ " FoodItemName VARCHAR(255), "
				+ " UnitPrice VARCHAR(255)," 
				+ " InStock VARCHAR(255))";

		try (Connection conn = dataSource.getConnection(); Statement stmt = conn.createStatement()) {

			stmt.executeUpdate(createSqlFoodItemTbl);

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	
	private void insertInitFoodItem() { 

		add(new Food("Pasta","399.99","Full Inventory"));
		add(new Food("Pizza Pie","590.75","Out Of Stock"));
		add(new Food("Buffalo Wings","799.85","Full Inventory"));
		add(new Food("Chicken","999.99","Limited Stock"));
		add(new Food("Baby Ribs","509.75","Full Inventory"));
	}
	
	
	@Override
	public List<Food> findAll(){
		return findByDelivery(null,null,null);
	}
	
	@Override
	//FINDING ID
	public Food find(Long id) {

		Food food = null;

		if (id != null) {
			String sqlFood = "SELECT id, FoodItemName, UnitPrice, InStock FROM FoodItemTbl where id = ?";
			try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(sqlFood)) {

				ps.setInt(1, id.intValue());
				ResultSet results = ps.executeQuery();

				if (results.next()) {
					food = new Food(Long.valueOf(results.getInt("id")), results.getString("FoodItemName"),
							results.getString("UnitPrice"), results.getString("InStock"));
				}

			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}

		return food;
	}
	
	@Override
	public List<Food> findByDelivery(String FoodItemName, String UnitPrice, String InStock) {
		List<Food> foods = new ArrayList<>();

		String sqlFood = "SELECT id, FoodItemName, UnitPrice, InStock FROM FoodItemTbl WHERE FoodItemName LIKE ? AND UnitPrice LIKE ? AND InStock LIKE ?";

		try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(sqlFood)) {

			ps.setString(1, createSearchValue(FoodItemName));
			ps.setString(2, createSearchValue(UnitPrice));
			ps.setString(3, createSearchValue(InStock));
			
			ResultSet results = ps.executeQuery();

			while (results.next()) {
				Food food = new Food(Long.valueOf(results.getInt("id")), results.getString("FoodItemName"),
						results.getString("UnitPrice"), results.getString("InStock"));
				foods.add(food);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}

		return foods;
	}
	
	
	private String createSearchValue(String string) {
		
		String value;
		
		if (StringUtils.isBlank(string)) {
			value = "%";
		} else {
			value = string;
		}
		
		return value;
	}
	

	@Override
	public void add(Food food) {
		
		String insertSqlFood = "INSERT INTO FoodItemTbl (FoodItemName, UnitPrice, InStock) VALUES (?, ?, ?)";

		try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(insertSqlFood)) {

			ps.setString(1, food.getFoodItemName());
			ps.setString(2, food.getUnitPrice());
			ps.setString(3, food.getInStock());
			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	@Override
	public void update(Food food) {
		String updateSqlFood = "UPDATE FoodItemTbl SET FoodItemName = ?, UnitPrice = ?, InStock = ? WHERE id = ?";

		try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(updateSqlFood)) {

			ps.setString(1, food.getFoodItemName());
			ps.setString(2, food.getUnitPrice());
			ps.setString(3, food.getInStock());
			ps.setLong(4, food.getId());
			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}


	@Override
	public void delete(Long id) {
		String updateSqlFood = "DELETE FROM FoodItemTbl WHERE id = ?";

		try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(updateSqlFood)) {

			ps.setLong(1, id);
			ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}
	
 //--------------//--------------//--------------//--------------//--------------//--------------//--------------//--------------//
	
	//ORDERTBL & INITORDER
	
		private void createOrderTbl() {
			String createSqlOrderTbl = "CREATE TABLE OrderTbl " 
					+ "(id INTEGER IDENTITY PRIMARY KEY, " 
					+ " CustomerName VARCHAR(255), "
					+ " Address VARCHAR(255), "
					+ " ContactNumber VARCHAR(255))";

			try (Connection conn = dataSource.getConnection(); Statement stmt = conn.createStatement()) {

				stmt.executeUpdate(createSqlOrderTbl);

			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}

		private void insertInitOrder() {

			addOrder(new Order("Haide","California","022-011"));
			addOrder(new Order("Steve","LA","033-055"));
		}
		
		@Override
		public List<Order> findAllOrder(){
			return findByOrder(null,null,null);
		}
		
		@Override
		//FINDING ID
		public Order findOrder(Long id) {

			Order order = null;

			if (id != null) {
				String sqlOrder = "SELECT id, CustomerName, Address, ContactNumber FROM OrderTbl where id = ?";
				try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(sqlOrder)) {

					ps.setInt(1, id.intValue());
					ResultSet results = ps.executeQuery();

					if (results.next()) {
						order = new Order(Long.valueOf(results.getInt("id")), results.getString("CustomerName"),
								results.getString("Address"), results.getString("ContactNumber"));
					}

				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException(e);
				}
			}

			return order;
		}
		
		@Override
		public List<Order> findByOrder(String CustomerName, String Address, String ContactNumber) {
			List<Order> orders = new ArrayList<>();

			String sqlOrder = "SELECT id, CustomerName, Address, ContactNumber FROM OrderTbl WHERE CustomerName LIKE ? AND Address LIKE ? AND ContactNumber LIKE ?";

			try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(sqlOrder)) {

				ps.setString(1, createSearchValues(CustomerName));
				ps.setString(2, createSearchValues(Address));
				ps.setString(3, createSearchValues(ContactNumber));
				
				ResultSet results = ps.executeQuery();

				while (results.next()) {
					Order order = new Order(Long.valueOf(results.getInt("id")), results.getString("CustomerName"),
							results.getString("Address"), results.getString("ContactNumber"));
					orders.add(order);
				}

			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}

			return orders;
		}
		
		
		private String createSearchValues(String string) {
			
			String value;
			
			if (StringUtils.isBlank(string)) {
				value = "%";
			} else {
				value = string;
			}
			
			return value;
		}
		

		@Override
		public void addOrder(Order order) {
			
			String insertSqlOrder = "INSERT INTO OrderTbl (CustomerName, Address, ContactNumber) VALUES (?, ?, ?)";

			try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(insertSqlOrder)) {

				ps.setString(1, order.getCustomerName());
				ps.setString(2, order.getAddress());
				ps.setString(3, order.getContactNumber());
				ps.executeUpdate();

			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}

		@Override
		public void updateOrder(Order order) {
			String updateSqlOrder = "UPDATE OrderTbl SET CustomerName = ?, Address = ?, ContactNumber = ? WHERE id = ?";

			try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(updateSqlOrder)) {

				ps.setString(1, order.getCustomerName());
				ps.setString(2, order.getAddress());
				ps.setString(3, order.getContactNumber());
				ps.setLong(4, order.getId());
				ps.executeUpdate();

			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}


		@Override
		public void deleteOrder(Long id) {
			String updateSqlOrder = "DELETE FROM OrderTbl WHERE id = ?";

			try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(updateSqlOrder)) {

				ps.setLong(1, id);
				ps.executeUpdate();

			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
		
		@Override
		public void selectOrder(Order order) {
			
			String selectSqlOrder = "SELECT id, CustomerName, Address, ContactNumber FROM OrderTbl WHERE CustomerName LIKE ? AND Address LIKE ? AND ContactNumber LIKE ?";

			try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(selectSqlOrder)) {

				ps.setString(1, order.getCustomerName());
				ps.setString(2, order.getAddress());
				ps.setString(3, order.getContactNumber());
				ps.executeUpdate();

			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
		
		 //--------------//--------------//--------------//--------------//--------------//--------------//--------------//--------------//
		
		private void createOrderItemsTbl() {
			String createSqlOrderItemsTbl = "CREATE TABLE OrderItemTbl " 
					+ "(id INTEGER IDENTITY PRIMARY KEY, " 
					+ " Quantity VARCHAR(255), "
					+ " TotalPrice VARCHAR(255))";

			try (Connection conn = dataSource.getConnection(); Statement stmt = conn.createStatement()) {

				stmt.executeUpdate(createSqlOrderItemsTbl);

			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
		
		private void insertInitOrderItem() { 

			addOrderItem(new OrderItem("20","100.98"));
			addOrderItem(new OrderItem("15","303.876"));
			addOrderItem(new OrderItem("8","44.97"));
		}
		

		@Override
		public List<OrderItem> findAllOrderItem(){
			return findByOrderItem(null,null);
		}
		
		@Override
		//FINDING ID
		public OrderItem findOrderItem(Long id) {

			OrderItem orderItem = null;

			if (id != null) {
				String sqlOrderItem = "SELECT id, Quantity, TotalPrice FROM OrderItemTbl where id = ?";
				try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(sqlOrderItem)) {

					ps.setInt(1, id.intValue());
					ResultSet results = ps.executeQuery();

					if (results.next()) {
						orderItem = new OrderItem(Long.valueOf(results.getInt("id")), results.getString("Quantity"),
								results.getString("TotalPrice"));
					}

				} catch (SQLException e) {
					e.printStackTrace();
					throw new RuntimeException(e);
				}
			}

			return orderItem;
		}
		

		
		@Override
		public List<OrderItem> findByOrderItem(String Quantity, String TotalPrice) {
			List<OrderItem> orderItems = new ArrayList<>();

			String sqlOrderItem = "SELECT id, Quantity, TotalPrice FROM OrderItemTbl WHERE Quantity LIKE ? AND TotalPrice LIKE ?";

			try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(sqlOrderItem)) {

				ps.setString(1, createSearchValueOrderItems(Quantity));
				ps.setString(2, createSearchValueOrderItems(TotalPrice));
				
				ResultSet results = ps.executeQuery();

				while (results.next()) {
					OrderItem orderItem = new OrderItem(Long.valueOf(results.getInt("id")), results.getString("Quantity"),
							results.getString("TotalPrice"));
					orderItems.add(orderItem);
				}

			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}

			return orderItems;
		}
		
		
		private String createSearchValueOrderItems(String string) {
			
			String value;
			
			if (StringUtils.isBlank(string)) {
				value = "%";
			} else {
				value = string;
			}
			
			return value;
		}
		

		@Override
		public void addOrderItem(OrderItem orderItem) {
			
			String insertSqlOrderItem = "INSERT INTO OrderItemTbl (Quantity, TotalPrice) VALUES ( ?, ?)";

			try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(insertSqlOrderItem)) {

				ps.setString(1, orderItem.getQuantity());
				ps.setString(2, orderItem.getTotalPrice());
				ps.executeUpdate();

			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}

		@Override
		public void updateOrderItem(OrderItem orderItem) {
			String updateSqlOrderItem = "UPDATE OrderItemTbl SET Quantity = ?, TotalPrice = ? WHERE id = ?";

			try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(updateSqlOrderItem)) {

				ps.setString(1, orderItem.getQuantity());
				ps.setString(2, orderItem.getTotalPrice());
				ps.setLong(3, orderItem.getId());
				ps.executeUpdate();

			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}


		@Override
		public void deleteOrderItem(Long id) {
			String updateSqlOrderItem = "DELETE FROM OrderItemTbl WHERE  id = ?";

			try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(updateSqlOrderItem)) {

				ps.setLong(1, id);
				ps.executeUpdate();

			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}

}
